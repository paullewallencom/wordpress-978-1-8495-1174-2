jQuery(function(){ /*<- shortcut for document ready*/

/*----Read Me:

Chapter 3, jQuery Basics examples.

Read through chapter 3 and just un-comment and re-comment 
each line (or block!) of code to experiement with jQuery's 
basic functionality in WordPress. 

Have fun!

------------*/

/*This is the initial test that ends up moved into the author-bio-plugin. - see additional zip for this chapter*/

//jQuery(".authorName > div").hide();
    
   /* jQuery(".authorName > .authorBio").hide().parent().css("cursor", "pointer").hover(function(evnt) {

    	jQuery(this).find("div").css("position","absolute").css("margin-top","-10px").css("width","400px").css("border", "1px solid #666").fadeIn("slow");

    }, function() {
    	jQuery(this).find("div").fadeOut("slow");

    });
;

	/*jQuery(".authorName").hover(function() {
    	jQuery(this).find(".authorBio").css("position","absolute").css("margin-top","-10px").css("width","400px").css("border", "1px solid #666").fadeIn("slow");

    }, function() {
    	jQuery(this).find(".authorBio").fadeOut("slow");

    });*/


});//end docReady