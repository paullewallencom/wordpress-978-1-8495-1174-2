== jQuery Add Author Bio ==
Created by: Tessa Blakeley Silver for the book: WordPress and jQuery by Packt Publishing
Tags: jQuery, the loop
Minimum Rquirement: 2.0
Tested up to: 2.9

== Description ==
It adds the author's first name and lastname or thier nickname wrapped in an .authorName class. If the author has a description, that is added in a .authorBio class. Last, a a custom .authorBio style sheet and jQuery plugin to hover the user's bio is added. This plugin has been created for educational purposes only for the book WordPress and jQuery for Packt Publishing 2010.

== Installation ==
unzip the files into the wp-content/plugin directory. Navigate to the Admin|Plugins|Installed page and activate.

== Changelog ==
---v 1.2---
WordPress and jQuery Chapter 3 -plugin expanded to remove the author tag if present in loop
a custom page is added to the admin where author name and bio div class names can be customized and jQuery hover effect is optional. ()

---v 1.0---
WordPress and jQuery Chapter 2 - basic WP plugin w/ jQuery Plugin.